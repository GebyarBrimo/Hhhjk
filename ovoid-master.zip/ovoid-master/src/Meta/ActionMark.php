<?php

namespace Stelin\Meta;

/**
 * Action Mark
 *
 * Transfer OVO
 * Transfer Antar BANK
 */
class ActionMark
{
    const TRANSFER_OVO = 'trf_ovo';
    const TRANSFER_BANK = 'trf_other_bank';
}
