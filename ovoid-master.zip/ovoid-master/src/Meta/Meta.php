<?php
namespace Stelin\Meta;

/**
 * Meta
 *
 * berisi config
 */
class Meta
{
    const OS          = 'Android';
    const OS_VERSION  = '9.0';
    const CLIENT_ID   = 'ovo_android';
    const APP_ID      = 'C7UMRSMFRZ46D9GW9IK7';
    const APP_VERSION = '3.45.0';
    const OS_NAME     = 'Android';
    const MAC_ADDRESS = '02:00:00:44:55:66';
}
