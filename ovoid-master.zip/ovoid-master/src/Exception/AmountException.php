<?php

namespace Stelin\Exception;

class AmountException extends \Exception
{
}