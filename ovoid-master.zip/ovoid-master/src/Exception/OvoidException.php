<?php
namespace Stelin\Exception;

class OvoidException extends \Exception
{
}