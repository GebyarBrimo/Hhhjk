<?php
namespace Stelin\Response;

class CustomerUnlockResponse
{
    public function __construct($data)
    {
        
    }
}