<?php

namespace Stelin\Response;

class LogoutResponse
{
    public function __construct($data)
    {
    }
}
